Pyshield, make python more easily
=================================

Pyshield is one integrated development platform that supports Python
script editing, debugging and running encrypted python scripts.

Main Features
-------------

* Syntax highlight and code block fold
* Complete symbol as python syntax
* Jump to the definition of symbol
* Find all reference of the symbol in multi-directories.
* Run script and jump to the line of exception occurred in script
* GUI Debugger
* Distribute encrypted python scripts other than literal scripts
* Integrated with version control tool git
* Extension by python script and external tools

Supported platforms
-------------------

Windows, Linux are supported, The following operation systems have
been tested:

* Windows XP, Windows7 both x86 and amd64
* Ubuntu both i686, x86_64

Installation
============

* Install Python 3.3 if not, download package from

  https://www.python.org/downloads/

* Install PySide for Python 3.3, see

  https://pypi.python.org/pypi/PySide/

* Download pyshield package from pypi.python.org or the following any url

  http://dashingsoft.com/products/pyshield/pyshield-1.8.0a1.zip

  http://dashingsoft.com/products/pyshield/pyshield-1.8.0a1.tar.bz2

  http://dashingsoft.com/products/pyshield/pyshield-1.8.0a1.tar.gz

* Extract the downloaded package to any path, for example, c:/pyshield
  or /opt/pyshield

* Start pyshield

  `For Windows,`::

    c:> cd \pyshield
    c:> C:\Python33\python pyshield.py

  `In Linux,`::

    $ cd /opt/pyshield
    $ /usr/local/bin/python3.3 pyshield.py

Screen shots
============

Edit Script

  http://dashingsoft.com/products/pyshield/images/pyshield-edit.png

Run Script

  http://dashingsoft.com/products/pyshield/images/pyshield-run.png

Debug Script

  http://dashingsoft.com/products/pyshield/images/pyshield-debug.png

Usage
=====

The basic scenario will be that, first to create and edit your python
script, then run it. If necessary, start debugger to debug the
script. At last, encrypt python scripts and distribute to customer.

Edit Script
-----------

The mainly features for python coding:

Goto definition of class/function
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
In the edit buffer, after press Ctrl+Alt+G, the cursor will jump to
the definition of the symbol in current cursor.

`For example,`::

  1: import os
  2: import sys
  3: import Myclass
  4: 
  5: a = Myclass()
  6: a.actionLaunch(os.path.join(os.getcwd(), 'myapp'))
  
Cursor in the word "os" of line 1, it'll open "os.py"

Cursor in the word "sys" of line 2, it'll do nothing because sys is
internal module.

Cursor in the word "Myclass" of line 3, it'll open "Myclass.py" by
search python path.

Cursor in the word "Myclass of line 5, it'll open "Myclass.py" and
jump to the line in which Myclass defined.

Cursor in the word actionLaunch in the line 6, it'll open "Myclass.py"
and jump to the line in which method "actionLaunch" of Myclass
defined.

Find all references of class/function
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In the edit buffer, after press Alt+R, the refactor panel will show
below the buffer. Specify scope, then click Search. The search results
panel will list all the refereneces in the scope. Click each item to
show the content in the buffer.

Refactor symbol
~~~~~~~~~~~~~~~

In the edit buffer, after press Ctrl+R, the refactor panel will show
below the buffer. Specify scope, then click Search. The search results
panel will list all the refereneces in the scope.

Type new name, click replace to refactor.


Complete symbol
~~~~~~~~~~~~~~~

Alt+/ to complete current symbol.


Show prototype of function/class
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Ctrl+/ to show the prototype of current function/method, Esc to close
prototype box.

Run Script
----------

Click run to run current script, the output of stderr and stdout will
print in the console panel. If there is exception when running script,
click the exception in the console panel will to show the source line
in the edit buffer.

If the script need to get input from stdin, type text in the bottom
box in the console panel, then type Enter.

Click New Run, you can set running environments, such as Python,
Python Path, command line options etc.

Debug Script
------------

Click Debug to start debugger

Run script by Step/Step Out/Continue

Check variable value in Varialbe Panel, or show expression value in
Watch Panel

Add Breakpoint, or Data Breakpoint in Breakpoint Panel

Click New Debug to start debugger in new python environments: Python,
Python Path, command line options etc.

Encrypt Script
--------------

Generate Project Capsule

Single file

Many files

Project files

Advanced Usage
==============

There are 3 ways to change Pyshield behavious:

  * Option Dialog
  * Pyshield Extensions.
  * Extnernal Tools.

Option Dialog
-------------

Most of behavious of pyshield could be controlled by some option. All
of these options could be customized by Option Dialog, or change in
the configuration file.

Pyshield Extensions
-------------------

Pyshield Extension is a python script which could be integrated into
pyshield. Most of pyshield behavious could be changed and extended by
Pyshield Extension.

External Tools
--------------

The third-party tools could be integrated into Pyshield by following
some rulers. The common cases include shell command intepreter,
version control tool.

Bug reports
===========

Send an email to: ``jondy.zhao@gmail.com``, Thanks.

More Information
================

The trial license will be expired in the end of this quarter, after
that, you need pay for registration code from

  http://dashingsoft.com/products/pyshield.html

You will receive information electronically immediately after
ordering, then replace the content of "license.lic" with registration
code only (no newline).

Copyright (c) 2009 - 2014 Dashingsoft Corp. All rights reserved.

2014-11-03 13:57 + China Standard Time
